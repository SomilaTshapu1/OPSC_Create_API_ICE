package com.example.apiapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class ComplaintActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    Button submitBtn;
    Button viewBtn;
    EditText unitText;
    EditText complaintText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaint);

        mAuth = FirebaseAuth.getInstance();
        unitText = findViewById(R.id.editTextUnitID);
        complaintText = findViewById(R.id.editTextComp);
        submitBtn = findViewById(R.id.submitBtn);
        viewBtn = findViewById(R.id.ViewBtn);

        viewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent viewIntent = new Intent(ComplaintActivity.this,CompHistoryActivity.class);
                startActivity(viewIntent);
            }
        });

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String editTextUnitID = unitText.getText().toString();
                String editTextComp = unitText.getText().toString();
                if (TextUtils.isEmpty(editTextUnitID)||TextUtils.isEmpty(editTextComp)){
                    Toast.makeText(ComplaintActivity.this,"Write your complaint or unit number!",Toast.LENGTH_SHORT).show();
                }
                else if (complaintText.length() <300){
                    Toast.makeText(ComplaintActivity.this,"Complaint must be less than 300 words!",Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}