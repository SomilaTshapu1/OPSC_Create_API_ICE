package com.example.apiapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    EditText unitIDText, nameText, surnameText, emailText, cellnumberText, yearText, passwordText;
    Button captureBtn, loginBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        unitIDText = findViewById(R.id.UnitID);
        nameText = findViewById(R.id.name);
        surnameText = findViewById(R.id.surname);
        emailText  = findViewById(R.id.email);
        cellnumberText = findViewById(R.id.number);
        yearText = findViewById(R.id.year);
        passwordText = findViewById(R.id.password);
        captureBtn = findViewById(R.id.captureBtn);
        loginBtn = findViewById(R.id.loginBtn);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(MainActivity.this,LoginActivity.class);
                startActivity(loginIntent);
            }
        });

        captureBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String unitID = unitIDText.getText().toString();
                String name = nameText.getText().toString();
                String surname = surnameText.getText().toString();
                String email = emailText.getText().toString();
                String number = cellnumberText.getText().toString();
                String year = yearText.getText().toString();
                String password = passwordText.getText().toString();
                if(TextUtils.isEmpty(unitID)||TextUtils.isEmpty(name)||TextUtils.isEmpty(surname)||TextUtils.isEmpty(email)||TextUtils.isEmpty(number)
                    ||TextUtils.isEmpty(year)||TextUtils.isEmpty(password)){
                    Toast.makeText(MainActivity.this,"Enter every details",Toast.LENGTH_SHORT).show();
                }
                else if (password.length() < 6){
                    Toast.makeText(MainActivity.this,"Password must be 6 characters",Toast.LENGTH_SHORT).show();
                }
                else{
                    mAuth.createUserWithEmailAndPassword(email,password)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()){
                                        Toast.makeText(MainActivity.this,"Account Created Successfully",Toast.LENGTH_SHORT).show();
                                    }
                                    else {
                                        Toast.makeText(MainActivity.this,"Account was not created",Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });
                }
            }

        });

    }
}
